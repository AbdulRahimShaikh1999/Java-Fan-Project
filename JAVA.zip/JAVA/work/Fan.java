package work;


public class Fan {
    //A special class used to store the list of constants
    enum Direction {
        FORWARD,
        BACKWARD;
    }
    
    //variable indicating off speed setting which is fixed.
    public static final int off=0;
    
    //variable showing the speed of fan other than off
    private int speed=0;
    
    //Initially setting the direction of fan to forward
    private Direction fanDirection=Direction.FORWARD;
    
    //function to get speed
    public int getSpeed()
    {
        return speed;
    }
    
    //function to get direction
    public Direction getDirection()
    {
        return fanDirection;
    }
    
    //function to change speed settings as required.
    public void increaseFanSpeed()
    {
        if(speed==3)
        {
            //as speed 3 sets to off setting.
            speed=off;
        }
        else
        {
            speed=speed+1;
        }
    }
    
    //function to reverse fan direction as desired.
    public void reverseDirection()
    {
        if(fanDirection==Direction.FORWARD)
        {
            fanDirection=Direction.BACKWARD;
        }
        else
        {
            fanDirection=Direction.FORWARD;
        }
    }
    
    //function to print fan speed and direction
    public void printDetails()
    {
        System.out.println("The fan speed is:"+speed);
        System.out.println("The fan direction is:"+fanDirection);
    }
    
    
}
