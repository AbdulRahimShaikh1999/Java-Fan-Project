package work;
//to use direction enum
import work.Fan.Direction;



//test class to test fan class functionalities.
public class Work {
    //Fan class object to access functionalities of fan class.
    private Fan obj;
    
    //Constructor of work class.
    public Work()
    {
        obj=new Fan();
    }
    
    //Function to test forward speedup
    public void testForwardSpeedUp()
    {
        System.out.println("Testing forward speedup");
        //to test for speed 0.
        if(obj.getDirection()==Direction.FORWARD)
        {
            if(obj.getSpeed()==0) //which shows off speed
            {
                obj.increaseFanSpeed();
            }
        }
        obj.printDetails();
        
        //To test for reamaining speeds.
        for(int i=1;i<=3;i++)
        {
            if(obj.getDirection()==Direction.FORWARD)
            {
                if(obj.getSpeed()==i) //which shows off speed
                {
                  obj.increaseFanSpeed();
                  obj.printDetails();
                }
            }
            
        }
    }
    
    //function to test backward speedup
    public void testBackwardSpeedup()
    {
        System.out.println("Testing backward speedup");
        //checking for forward direction to reverse the direction.
        if(obj.getDirection()==Direction.FORWARD)
        {
            if(obj.getSpeed()==0)
            {
                obj.reverseDirection();
            }
        }
        //checking for speed 0 for backward.
        if(obj.getDirection()==Direction.BACKWARD)
        {
            if(obj.getSpeed()==0)
            {
                obj.increaseFanSpeed();
            }
        }
        //printing the details for backward position
        obj.printDetails();
        
        //testing backward for other speeds.
        for(int i=1;i<=3;i++)
        {
            if(obj.getDirection()==Direction.BACKWARD)
            {
                if(obj.getSpeed()==i)
                {
                  obj.increaseFanSpeed();
                  obj.printDetails();
                }
            }
        }
    }
    
    //main function.
    public static void main(String[] args) 
    {
        Work temp=new Work();
        //calling forward speedup function
        temp.testForwardSpeedUp();
        //calling backward speedup function
        temp.testBackwardSpeedup();
    }
}
